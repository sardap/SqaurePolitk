﻿#if UNITY_EDITOR

using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


namespace EModules.Snap
{
  public class IconsMenu
  {
    [MenuItem("Asd/asd")]
    public static void ASD()
    {
      var files = System.IO.Directory.GetFiles( Application.dataPath + "/Plugins/Simple SNAP Buttons for Inspector/icons referense", "*.png", System.IO.SearchOption.TopDirectoryOnly );
      foreach (var f in files)
      {
        var txt =  System.IO.File.ReadAllBytes(f);
        System.IO.File.WriteAllText(f.Replace( ".png",".txt" ), Convert.ToBase64String(txt) );
      }
    }
  }
}

#endif


